---
name: frontend-e2e-test
description: 前端联调测试技能
license: MIT
---
# Frontend E2E Test
1. 测试上传审核链路。
2. 测试重复 tags 字段解析。
