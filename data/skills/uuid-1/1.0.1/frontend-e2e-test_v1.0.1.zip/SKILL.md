---
name: frontend-e2e-test
description: header 鉴权测试
license: MIT
---
# Header Auth Test
1. 验证 Authorization 请求头。
